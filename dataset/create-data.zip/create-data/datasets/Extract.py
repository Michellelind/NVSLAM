import json

# Load data for train
with open('/EEC193/data/BDD/bdd100k/labels/bdd100k_labels_images_train.json') as json_file:
    data_train = json.load(json_file)

# Load data for val
#with open('bdd100k_labels_images_val.json') as json_file:
#    data_val = json.load(json_file)

# Create data for trainA and trainB
trainA = open("bdd_data/trainA.txt", "w")    # day train images
trainB = open("bdd_data/trainB.txt", "w")    # night train images
for image in data_train:
    if image['attributes']['weather'] == 'clear':
        if image['attributes']['timeofday'] == 'daytime':
            trainA.write(image['name']+'\n')
        if image['attributes']['timeofday'] == 'night':
            trainB.write(image['name']+'\n')
trainA.close()
trainB.close()

#create data for valA and valB

#valA = open("valA.txt", "w")    # day val images
#valB = open("valB.txt", "w")    # night val images
#for image in data_val:
#    if image['attributes']['weather'] == 'clear':
#        if image['attributes']['timeofday'] == 'daytime':
#            valA.write(image['name']+'\n')
#        if image['attributes']['timeofday'] == 'night':
#            valB.write(image['name']+'\n')
#valA.close()
#valB.close()
