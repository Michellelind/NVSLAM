python test.py --dataroot KITTI/03/image_2 \
               --name day2night \
               --model test \
               --no_dropout \
               --preprocess scale_width \
               --load_size 1024 \
               --num_test 1 \
               --model_suffix "_A"